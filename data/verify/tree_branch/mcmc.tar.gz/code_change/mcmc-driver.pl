#!/usr/bin/env perl
use strict;

if (@ARGV != 3) {
	die "Usage: perl one_round_fwd-epc.pl <dependence_superscript> <num_mcmc_steps> <sequence_length>.\n";
}

my $dependence_superscript = shift;
#my $num_replicates = shift;
my $MCMC = shift;
my $seq_size = shift;

my $num_replicates = 1;

my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
my $file = "run_" . $hour . "." . $min . "." . $sec;
my $num_runs = 1;

my $INDEPENDENT_SITES = 0;
my $EMULATE = 0;

my $return_val_fwd;
my $return_val_epc;

my @ret_split;

my $branch_length = 
#		 0.01,
#		 0.5,
		 2.0,
#		10.0
		;
		
my $filename = "one_round_fwdepc-$branch_length-$dependence_superscript";
my $indel_seq_gen = "isg-test-one";

open OUTt, ">$filename.tree";
print OUTt "[$seq_size](T_1:$branch_length,T_2:0);\n";
close OUTt;

if ($INDEPENDENT_SITES) {
	$return_val_fwd = `./$indel_seq_gen -m JC69 -e $filename -o f < $filename.tree`;
	$return_val_epc = `./$indel_seq_gen -m JC69 -E $filename.sim.ma < $filename.tree`;
} else {
	#### 1029: EPC HAS AN OOPS
	my $fwd_command = "";
	$fwd_command .= "-m JC69 -z 1039,2001,3001,4001 -D $dependence_superscript -e $filename -o f ";
	$fwd_command .= " -n $num_runs ";		## This is only to test if fwd can be run multiple times. Does not yet work with EPC following. ##
	$fwd_command .= "< $filename.tree";
	print "$fwd_command\n ";
	$return_val_fwd = `./$indel_seq_gen $fwd_command`;
	print STDERR "----- END-POINT CONDITIONED RUN -------------\n";
	my $epc_command = "";
	$epc_command .= "-m JC69 -z 9966,2001,3001,4001 -D $filename.sim.dep -E $filename.sim.ma ";
	if ($EMULATE) {
		$epc_command .= " -M $filename.sim.trace ";
	} else {
		$epc_command .= " -n $num_replicates ";
	}
	if ($MCMC) {
		$epc_command .= " --mcmc $MCMC "
	}
	$epc_command .= " < $filename.tree";
	print "$epc_command\n ";
	$return_val_epc = `./$indel_seq_gen $epc_command`;
	open OUT, ">$filename.results";
	print OUT "$return_val_epc\n";
	close OUT;
}

print STDERR "Reps: $num_replicates\n";
print STDERR "Power: $dependence_superscript\n";
print STDERR "MCMC: Last $MCMC lines in file $filename.results.\n";